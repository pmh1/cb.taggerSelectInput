<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '#taggerSelectInput

Adds inputs to ContentBlocks for selecting Tagger groups and Tags.
Both Group and Tag inputs are single select.
',
    'changelog' => '1.0.0-rc1
============
Initial build
',
    'requires' => 
    array (
      'tagger' => '>=1.9.0',
      'contentblocks' => '>=1.5.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cd1ec9cc4da755fc743c156c514e857a',
      'native_key' => 'taggerselectinput',
      'filename' => 'modNamespace/be3b9f59ce59c066280283a81beb887d.vehicle',
      'namespace' => 'taggerselectinput',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '286aab26edf76c2e3e0b089036f51dda',
      'native_key' => NULL,
      'filename' => 'modCategory/64ac5d49734c43133a2f3b28f124da93.vehicle',
      'namespace' => 'taggerselectinput',
    ),
  ),
);