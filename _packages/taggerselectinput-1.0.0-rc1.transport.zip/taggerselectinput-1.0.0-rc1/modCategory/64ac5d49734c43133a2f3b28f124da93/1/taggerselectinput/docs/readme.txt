#taggerSelectInput

Adds inputs to ContentBlocks for selecting Tagger groups and Tags.
Both Group and Tag inputs are single select.
