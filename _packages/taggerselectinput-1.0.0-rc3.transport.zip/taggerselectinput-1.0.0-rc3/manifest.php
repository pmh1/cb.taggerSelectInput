<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '# taggerSelectInput

Adds inputs to ContentBlocks for selecting Tagger groups and Tags.
Both Group and Tag inputs are single select.
',
    'changelog' => '1.0.0-rc3
============
Fix issue when using Input outside the scope of a page.

1.0.0-rc2
============
Change tag and group listing limit to 0 (all)

1.0.0-rc1
============
Initial build
',
    'requires' => 
    array (
      'tagger' => '>=1.9.0',
      'contentblocks' => '>=1.5.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ebb32e98f7fe9f3ac330f08c9965cdc0',
      'native_key' => 'taggerselectinput',
      'filename' => 'modNamespace/cdeb8a7c94694fdf925fa66686cae0dc.vehicle',
      'namespace' => 'taggerselectinput',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '42afe54f6cd81f22244272142be0c292',
      'native_key' => NULL,
      'filename' => 'modCategory/b0e9f68c51b0ec97616286a33c9a335f.vehicle',
      'namespace' => 'taggerselectinput',
    ),
  ),
);