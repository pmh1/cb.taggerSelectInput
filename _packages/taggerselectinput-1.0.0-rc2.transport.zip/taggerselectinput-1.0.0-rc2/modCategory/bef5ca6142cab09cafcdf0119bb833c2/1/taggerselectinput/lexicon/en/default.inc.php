<?php
$_lang['taggerselectinput'] = "cb Tagger Select Input";
$_lang['taggerselectinput.name'] = "cb.taggerSelectInput";
$_lang['taggerselectinput.description'] = "Tagger Select Box(s) for modmore Contentblocks";
$_lang['taggerselectinput.group_select.name'] = "Tagger Group Select";
$_lang['taggerselectinput.group_select.description'] = "Select field that lists Tagger groups for the current context.";
$_lang['contentblocks.taggergroupselectinput_template.description'] = "Template for the Tagger Group Select filed. Available placeholders are [[+value]] (the id), [[+display]] (the name), and [[+alias]] (the alias).";
$_lang['taggerselectinput.tag_select.name'] = "Tagger Tag Select";
$_lang['taggerselectinput.tag_select.description'] = "Select field that lists Tagger Tags.";
$_lang['contentblocks.taggertagselectinput_template.description'] = "Template for the Tagger Tag Select field. Available placeholders are [[+value]] (the id), [[+display]] (the name), and [[+alias]] (the alias).";
