<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '# taggerSelectInput

Adds inputs to ContentBlocks for selecting Tagger groups and Tags.
Both Group and Tag inputs are single select.
',
    'changelog' => '1.0.0-rc2
============
Change tag and group listing limit to 0 (all)

1.0.0-rc1
============
Initial build
',
    'requires' => 
    array (
      'tagger' => '>=1.9.0',
      'contentblocks' => '>=1.5.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '601c47816d45b9aca5cbb744285e4d20',
      'native_key' => 'taggerselectinput',
      'filename' => 'modNamespace/68a137c91da258b2247261773a03c9a1.vehicle',
      'namespace' => 'taggerselectinput',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '35f02562e23a2c46eaf8dc9735a06a9d',
      'native_key' => NULL,
      'filename' => 'modCategory/bef5ca6142cab09cafcdf0119bb833c2.vehicle',
      'namespace' => 'taggerselectinput',
    ),
  ),
);